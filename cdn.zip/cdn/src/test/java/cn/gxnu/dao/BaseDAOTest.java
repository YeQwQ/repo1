package cn.gxnu.dao;

import java.sql.Connection;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

class BaseDAOTest {

    @org.junit.jupiter.api.Test
    void getConnection() throws SQLException {
        Connection conn= new BaseDAO_C3P0().getConnection();//得到mysql数据库连接对象，失败会返回null
        assertNotNull(conn);//预期不是null则表示数据库连接成功
    }
}