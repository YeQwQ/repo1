package cn.gxnu.dao;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbcp2.BasicDataSourceFactory;

import javax.sql.DataSource;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/**
 * 持久层类，用于连接mysql数据库和关闭mysql数据库
 */
public class BaseDAO_C3P0 {
    //获取mysql数据库的连接
    public Connection getConnection(){
        Connection conn = null;
        try {
            ComboPooledDataSource dataSource = new ComboPooledDataSource();
            conn = dataSource.getConnection();
        }catch (Exception e) {
            e.printStackTrace();
            System.out.println("从dbcp连接池中获取数据库连接失败");
        }
        return conn;
    }

    //关闭mysql连接
}
