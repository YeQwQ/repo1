package cn.gxnu.dao;

import cn.gxnu.util.DATA;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
//静态导入
import static cn.gxnu.util.DATA.*;

/*
 * 持久层类，用于连接mysql数据库和关闭mysql数据库
 */
public class BaseDAO {
    //获取mysql数据库的连接
    public Connection getConnection() throws SQLException {
    //1.加载mysql8.x驱动
        try {
            Class.forName(MYSQL_OLD_DRIVER);
        } catch (ClassNotFoundException e) {
            System.out.println("切换到mysql8.x驱动");
            try {
                Class.forName(MYSQL_NEW_DRIVER);
            } catch (ClassNotFoundException classNotFoundException) {
                System.out.println("mysql8.x驱动失败");
            }
        }

        //获取mysql8.x的连接对象
        /*
        *第一个参数表示数据库的路径名称
        *第二个参数表示登录数据库的账号
        *第三个参数表示登录数据库的密码
         */
        Connection conn= DriverManager.getConnection(MYSQL_URL,MYSQL_USER,MYSQL_PASSWORD);

        return conn;
    }

}
