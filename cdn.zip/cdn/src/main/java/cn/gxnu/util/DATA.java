package cn.gxnu.util;

/**
 * 数据字典类
 */
public class DATA {
    public static final String MYSQL_OLD_DRIVER="com.mysql.jdbc.Driver";
    public static final String MYSQL_NEW_DRIVER="com.mysql.cj.jdbc.Driver";
    public static final String MYSQL_URL="jdbc:mysql://localhost:3306/cdn";
    public static final String MYSQL_USER="root";
    public static final String MYSQL_PASSWORD="123456";
}
