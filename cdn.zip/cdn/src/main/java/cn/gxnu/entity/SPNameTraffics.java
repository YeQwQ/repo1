package cn.gxnu.entity;
//客户日流量类
import java.io.Serializable;

/*实体类，通常一个实体对应DBMS数据库中的一个表
* 实体java.io.Serializable接口，进行序列化，便于IO操作
 */
public class SPNameTraffics implements Serializable {
    //属性与表中的字段对应
    private int id;
    private String spname;
    private String traffics;
    private String createtime;

    //set/get方法

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSpname() {
        return spname;
    }

    public void setSpname(String spname) {
        this.spname = spname;
    }

    public String getTraffics() {
        return traffics;
    }

    public void setTraffics(String traffics) {
        this.traffics = traffics;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    //构造方法
    public SPNameTraffics(){}
    //由于表中的主键是自动增长，无需java中进行赋值，所以构造方法未包含对应属性的赋值
    public SPNameTraffics(String spname, String traffics, String createtime) {
        this.spname = spname;
        this.traffics = traffics;
        this.createtime = createtime;
    }

    public SPNameTraffics(int id, String spname, String traffics, String createtime) {
        this.id = id;
        this.spname = spname;
        this.traffics = traffics;
        this.createtime = createtime;
    }

//辅助方法


    @Override
    public String toString() {
        return "spnameTraffics{" +
                "id=" + id +
                ", spname='" + spname + '\'' +
                ", traffics='" + traffics + '\'' +
                ", createtime='" + createtime + '\'' +
                '}';
    }
}
