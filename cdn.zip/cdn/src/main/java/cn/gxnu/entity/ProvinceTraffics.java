package cn.gxnu.entity;
//省份日流量类
import java.io.Serializable;

/*实体类，通常一个实体对应DBMS数据库中的一个表
* 实体java.io.Serializable接口，进行序列化，便于IO操作
 */
public class ProvinceTraffics implements Serializable {
    //属性与表中的字段对应
    private int id;
    private String province;
    private String traffics;
    private String createtime;

    //set/get方法

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getTraffics() {
        return traffics;
    }

    public void setTraffics(String traffics) {
        this.traffics = traffics;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    //构造方法
    public ProvinceTraffics(){}
    //由于表中的主键是自动增长，无需java中进行赋值，所以构造方法未包含对应属性的赋值
    public ProvinceTraffics(String province, String traffics, String createtime) {
        this.province = province;
        this.traffics = traffics;
        this.createtime = createtime;
    }

    public ProvinceTraffics(int id, String province, String traffics, String createtime) {
        this.id = id;
        this.province = province;
        this.traffics = traffics;
        this.createtime = createtime;
    }

//辅助方法


    @Override
    public String toString() {
        return "provinceTraffics{" +
                "id=" + id +
                ", province='" + province + '\'' +
                ", traffics='" + traffics + '\'' +
                ", createtime='" + createtime + '\'' +
                '}';
    }
}
