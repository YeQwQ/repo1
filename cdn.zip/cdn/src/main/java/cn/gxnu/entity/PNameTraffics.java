package cn.gxnu.entity;
//产品日流量类
import java.io.Serializable;
/*实体类，通常一个实体对应DBMS数据库中的一个表
* 实体java.io.Serializable接口，进行序列化，便于IO操作
 */
public class PNameTraffics implements Serializable {
    //属性与表中的字段对应
    private int id;
    private String pname;
    private String traffics;
    private String createtime;

    //set/get方法

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getTraffics() {
        return traffics;
    }

    public void setTraffics(String traffics) {
        this.traffics = traffics;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    //构造方法
    public PNameTraffics(){}
    //由于表中的主键是自动增长，无需java中进行赋值，所以构造方法未包含对应属性的赋值
    public PNameTraffics(String pname, String traffics, String createtime) {
        this.pname = pname;
        this.traffics = traffics;
        this.createtime = createtime;
    }

    public PNameTraffics(int id, String pname, String traffics, String createtime) {
        this.id = id;
        this.pname = pname;
        this.traffics = traffics;
        this.createtime = createtime;
    }

//辅助方法


    @Override
    public String toString() {
        return "PNameTraffics{" +
                "id=" + id +
                ", pname='" + pname + '\'' +
                ", traffics='" + traffics + '\'' +
                ", createtime='" + createtime + '\'' +
                '}';
    }
}
